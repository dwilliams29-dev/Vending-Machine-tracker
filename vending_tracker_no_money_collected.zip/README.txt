VENDING TRACKER — SAFARI PHONE VERSION

Open index.html in Safari. Add it to your Home Screen for an app-like experience.

Features:
- Profit every day and profit this month.
- Purchases are expenses and automatically reduce profit.
- Purchase date, quantity bought, cost, machine, and expiration date.
- Matching product names update the existing product instead of creating duplicates.
- Purchases automatically add quantity to back stock.
- Record how many items were sold with one quantity entry.
- Sold quantity automatically subtracts from the machine.
- Low-stock warnings.
- Expiration warnings for expired products and products expiring within 7 days.
- Add multiple vending machines.
- Delete old machines; they appear under Deleted.
- Delete inventory items; they appear under Deleted.
- Restore deleted items.
- Dashboard puts cash and warnings on the same page.
- Mobile-friendly layout for Safari.
- Data stays in the browser on the device. Use Backup regularly.
